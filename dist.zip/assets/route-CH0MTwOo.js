import{i as r}from"./index-DlHvJvOv.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
