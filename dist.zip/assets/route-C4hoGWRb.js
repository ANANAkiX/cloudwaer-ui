import{i as r}from"./index-CBXuvKCa.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
