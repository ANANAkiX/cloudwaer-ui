import{i as r}from"./index-DW_cPm0I.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
