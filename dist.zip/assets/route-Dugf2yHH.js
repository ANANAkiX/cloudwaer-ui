import{i as r}from"./index-C2WpJMd1.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
