import{i as r}from"./index-CsdA4SMx.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
