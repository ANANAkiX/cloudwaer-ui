import{i as r}from"./index-CfVhFwoj.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
