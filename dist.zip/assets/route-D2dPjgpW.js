import{i as r}from"./index-DHZF0DMM.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
