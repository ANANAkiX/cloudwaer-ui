import{i as r}from"./index-BHUQPz5b.js";function t(){return r({url:"/admin/route/current",method:"get"})}export{t as getCurrentUserRoutes};
